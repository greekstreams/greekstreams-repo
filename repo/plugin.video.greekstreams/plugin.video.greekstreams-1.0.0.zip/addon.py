# -*- coding: utf-8 -*-
import sys
from urllib.parse import urlparse, parse_qs, urlencode, urljoin
import requests
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
import base64
import json
import xbmc
import os

# --- Addon specific info ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_HANDLE = int(sys.argv[1])
ADDON_VERSION = ADDON.getAddonInfo('version')

# --- Target Site Configuration ---
TARGET_HOST = 'https://www.stokourbeti.online'
TARGET_PATH = '/kourbetitv/'
LIST_URL = TARGET_HOST + TARGET_PATH

# --- Default Artwork Paths ---
DEFAULT_ICON = os.path.join(ADDON_PATH, 'default_icon.png')
ADDON_ICON = os.path.join(ADDON_PATH, 'icon.png')
ADDON_FANART = os.path.join(ADDON_PATH, 'fanart.jpg')

# --- Disclaimer Text ---
GREEK_DISCLAIMER = "Αποποίηση Ευθύνης: Το περιεχόμενο προέρχεται από ελεύθερες πηγές στο διαδίκτυο. Δεν φέρουμε ευθύνη για αυτό."

# --- Logging Function ---
def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID} v{ADDON_VERSION}] {msg}", level)

# --- Router ---
try:
    params = {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}
except Exception as e:
    log(f"Error parsing params: {sys.argv[2][1:]} - {e}", xbmc.LOGERROR)
    params = {}

mode = params.get('mode')
url = params.get('url')
name = params.get('name')
referer = params.get('referer')

# --- Functions ---
def build_url(query):
    return sys.argv[0] + '?' + urlencode(query)

def get_html_content(url_to_fetch, referer_url=None):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'en-US,en;q=0.9',
            'Upgrade-Insecure-Requests': '1',
        }
        if referer_url:
            parsed_fetch_url = urlparse(url_to_fetch)
            base_fetch_host = f"{parsed_fetch_url.scheme}://{parsed_fetch_url.netloc}"
            if '://' not in referer_url:
                if referer_url.startswith('/'): referer_url = urljoin(base_fetch_host, referer_url)
                else: referer_url = urljoin(url_to_fetch, referer_url)
            headers['Referer'] = referer_url
            headers['Sec-Fetch-Site'] = 'cross-site' if urlparse(referer_url).netloc != parsed_fetch_url.netloc else 'same-origin'
            headers['Sec-Fetch-Dest'] = 'iframe' if headers['Sec-Fetch-Site'] == 'cross-site' else 'document'
            log(f"Using Referer: {referer_url} for URL: {url_to_fetch}", xbmc.LOGDEBUG)
        else:
             headers['Sec-Fetch-Site'] = 'none'
             headers['Sec-Fetch-Dest'] = 'document'
        
        headers['Sec-Fetch-Mode'] = 'navigate'
        headers['Sec-Fetch-User'] = '?1'

        if not url_to_fetch or not url_to_fetch.startswith(('http://', 'https://')):
            log(f"Invalid URL scheme or empty URL: '{url_to_fetch}'", xbmc.LOGERROR)
            return None

        log(f"Fetching: {url_to_fetch} with headers: {headers}")
        response = requests.get(url_to_fetch, headers=headers, timeout=20, allow_redirects=True)
        response.raise_for_status()
        log(f"Response status: {response.status_code} for {url_to_fetch} (Final URL: {response.url})")
        
        if response.encoding is None: response.encoding = response.apparent_encoding
        if response.encoding is None: response.encoding = 'utf-8'
        log(f"Using encoding: {response.encoding} for {url_to_fetch}", xbmc.LOGDEBUG)
        
        return response.text
    except requests.exceptions.HTTPError as http_err:
        xbmcgui.Dialog().ok(f"{ADDON_NAME} - Network Error", f"A network problem occurred (Code: S{http_err.response.status_code}).\nPlease try again later or check the log for details.")
        log(f"HTTP Error fetching {url_to_fetch}: {http_err} - Response Text (if any): {http_err.response.text[:500]}", xbmc.LOGERROR)
        return None
    except requests.exceptions.RequestException as e:
        xbmcgui.Dialog().ok(f"{ADDON_NAME} - Network Error", "Could not connect to the required service.\nPlease check your internet connection or try again later. (Details in log)")
        log(f"Network Error fetching {url_to_fetch}: {e}", xbmc.LOGERROR)
        return None
    except Exception as e:
        xbmcgui.Dialog().ok(f"{ADDON_NAME} - Error", "An unexpected error occurred.\nPlease check the log for details.")
        log(f"Unexpected error fetching {url_to_fetch}: {e}", xbmc.LOGERROR)
        return None

def list_channels():
    log("Listing main events...")
    disclaimer_li = xbmcgui.ListItem(label=f"[B]{GREEK_DISCLAIMER}[/B]")
    art_data_disclaimer = {'icon': ADDON_ICON, 'thumb': ADDON_ICON}
    if os.path.exists(ADDON_FANART): art_data_disclaimer['fanart'] = ADDON_FANART
    disclaimer_li.setArt(art_data_disclaimer)
    infotag_disclaimer = disclaimer_li.getVideoInfoTag()
    infotag_disclaimer.setTitle("Αποποίηση Ευθύνης")
    infotag_disclaimer.setPlot(GREEK_DISCLAIMER)
    disclaimer_li.setProperty('IsPlayable', 'false')
    disclaimer_url = build_url({'mode': 'noop'})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=disclaimer_url, listitem=disclaimer_li, isFolder=False)

    html_content = get_html_content(LIST_URL)
    if not html_content:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        all_ul_lists = soup.find_all('ul', class_='float-box1')
        if not all_ul_lists:
            log(f"Parsing Warning - No event list container (ul.float-box1) found on {LIST_URL}. Only disclaimer shown.", xbmc.LOGWARNING)

        item_added = False
        for ul_list in all_ul_lists:
            list_items = ul_list.find_all('li', recursive=False)
            for item_li_tag in list_items:
                link_tag = item_li_tag.find('a')
                p_tags = item_li_tag.find_all('p')
                if link_tag and link_tag.has_attr('href'):
                    channel_path = link_tag['href']
                    if channel_path.startswith('/'): channel_url = TARGET_HOST + channel_path
                    elif channel_path.startswith('http'): channel_url = channel_path
                    else: channel_url = urljoin(LIST_URL, channel_path)
                    
                    title_parts = [p.get_text(strip=True) for p in p_tags if p.get_text(strip=True)]
                    if title_parts:
                        title_str = " / ".join(title_parts)
                        li = xbmcgui.ListItem(title_str)
                        art_data = {'icon': DEFAULT_ICON, 'thumb': DEFAULT_ICON}
                        if os.path.exists(ADDON_FANART): art_data['fanart'] = ADDON_FANART
                        li.setArt(art_data)
                        infotag = li.getVideoInfoTag()
                        infotag.setTitle(title_str)
                        infotag.setPlot(f"Event: {title_str}\nSelect link to play.")
                        infotag.setMediaType('video')
                        li.setProperty('IsPlayable', 'false')
                        action_url = build_url({'mode': 'list_links', 'url': channel_url, 'name': title_str})
                        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=action_url, listitem=li, isFolder=True)
                        item_added = True
                    else: log(f"Skipping item (no valid title found from p_tags) in {channel_url}.", xbmc.LOGDEBUG)
        if not item_added and all_ul_lists:
             log(f"No valid event items parsed from ul.float-box1 on {LIST_URL} (excluding disclaimer).", xbmc.LOGWARNING)
    except Exception as e:
         if 'item_added' in locals() and item_added:
              xbmcgui.Dialog().ok(f"{ADDON_NAME} - Listing Error", "Error processing event list.\n(Details in log)")
         log(f"Error in list_channels parsing content from {LIST_URL}: {e}", xbmc.LOGERROR)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_links(channel_page_url, original_event_name):
    log(f"Listing links for event: '{original_event_name}' from Channel Page URL: {channel_page_url}")
    html_content = get_html_content(channel_page_url, referer_url=LIST_URL)
    if not html_content:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
        return

    known_l3_url_patterns_to_show = [
        '/cdn3/linka.php',        # For Link 1 (was working)
        # '/cdn3/linkab.php',    # REMOVED: Leads to dead vodkapr3mium page (as per user feedback)
        '/cast/5/link1.php'       # For Link 7 (was working)
    ]

    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        link_tags = []
        buttons_div = soup.find('div', class_='buttons')
        if buttons_div:
            link_tags = buttons_div.find_all('a', class_='btn', onclick=True)
        
        if not link_tags:
             log("No 'div.buttons > a.btn[onclick]' found. Searching page for any 'a[onclick*=src=]' links...", xbmc.LOGDEBUG)
             link_tags = soup.find_all('a', onclick=re.compile(r"src\s*="))
        
        if not link_tags:
            log("No 'onclick' links found. Searching for generic 'a[href]' tags that might be player links...", xbmc.LOGDEBUG)
            potential_links = soup.find_all('a', href=True)
            for pl in potential_links:
                href = pl['href']
                if any(kw in href for kw in ['player', 'embed', 'cdn', 'live', 'stream', 'video', '.php', '.html']) and \
                   not href.startswith('#') and not href.startswith('javascript:'):
                    link_tags.append(pl)
            if link_tags:
                log(f"Found {len(link_tags)} potential player links via generic href search.", xbmc.LOGDEBUG)

        if not link_tags:
            xbmcgui.Dialog().ok(f"{ADDON_NAME} - No Links Found", f"No source links could be found for '{original_event_name.split(' - ')[0]}'.")
            log(f"Parsing Error - No links found on page: {channel_page_url}", xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
            return

        item_added_count = 0
        filtered_out_count = 0
        for i, link_tag in enumerate(link_tags):
            link_text_raw = link_tag.get_text(strip=True)
            link_text = link_text_raw if link_text_raw else f"Link {i+1}"
            
            iframe_target_url_raw = None 
            onclick_attr = link_tag.get('onclick')

            if onclick_attr:
                match = re.search(r"src\s*=\s*['\"]([^'\"]+)['\"]", onclick_attr)
                if match:
                    iframe_target_url_raw = match.group(1).strip()
            
            if not iframe_target_url_raw and link_tag.has_attr('href'):
                href_val = link_tag['href'].strip()
                if href_val and not href_val.startswith('#') and not href_val.startswith('javascript:'):
                    if any(kw in href_val for kw in ['player', 'embed', 'cdn', 'watch', 'stream', '.php', '.html']) or \
                       urlparse(href_val).path:
                        iframe_target_url_raw = href_val
            
            if iframe_target_url_raw:
                l3_player_url_for_resolve = iframe_target_url_raw
                if l3_player_url_for_resolve.startswith('//'): l3_player_url_for_resolve = 'https:' + l3_player_url_for_resolve
                elif not l3_player_url_for_resolve.startswith('http'): l3_player_url_for_resolve = urljoin(channel_page_url, l3_player_url_for_resolve)

                should_display_this_link = False
                for pattern in known_l3_url_patterns_to_show:
                    if pattern in l3_player_url_for_resolve:
                        should_display_this_link = True
                        log(f"Link '{link_text}' (L3 Player URL: {l3_player_url_for_resolve}) matches display pattern '{pattern}'. Will be shown.", xbmc.LOGDEBUG)
                        break
                
                if should_display_this_link:
                    log(f"Adding link to display list: '{link_text}' -> Player URL: {l3_player_url_for_resolve}", xbmc.LOGDEBUG)
                    list_item_name = f"{original_event_name} - {link_text}"
                    li = xbmcgui.ListItem(list_item_name)
                    art_data = {'icon': DEFAULT_ICON, 'thumb': DEFAULT_ICON}
                    if os.path.exists(ADDON_FANART): art_data['fanart'] = ADDON_FANART
                    li.setArt(art_data)
                    infotag = li.getVideoInfoTag()
                    infotag.setTitle(list_item_name)
                    infotag.setPlot(f"Source: {link_text}\nEvent: {original_event_name}") # Removed Player URL from user-facing plot
                    infotag.setMediaType('video')
                    li.setProperty('IsPlayable', 'true')
                    action_url = build_url({'mode': 'resolve_link', 'url': l3_player_url_for_resolve, 'name': list_item_name, 'referer': channel_page_url})
                    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=action_url, listitem=li, isFolder=False)
                    item_added_count += 1
                else:
                    filtered_out_count += 1
                    log(f"Link '{link_text}' (L3 Player URL: {l3_player_url_for_resolve}) does NOT match display patterns. Filtering out.", xbmc.LOGDEBUG)
            else:
                if onclick_attr: log(f"Could not parse target URL from onClick attribute: '{onclick_attr}' for link '{link_text}'", xbmc.LOGWARNING)
                elif link_tag.has_attr('href'): log(f"Skipping link '{link_text}' with href '{link_tag['href']}' as it's not a recognized player link pattern or yielded no URL.", xbmc.LOGDEBUG)
                else: log(f"Skipping link '{link_text}' as it has no onclick or href to process.", xbmc.LOGDEBUG)

        if filtered_out_count > 0:
            log(f"Filtered out {filtered_out_count} links that did not match display patterns.", xbmc.LOGINFO)

        if item_added_count == 0:
            log(f"No links matched display patterns for page: {channel_page_url}", xbmc.LOGWARNING)
            if not link_tags:
                 xbmcgui.Dialog().ok(f"{ADDON_NAME} - No Links Found", f"No source links could be found for '{original_event_name.split(' - ')[0]}'.")
            else:
                 xbmcgui.Dialog().ok(f"{ADDON_NAME} - No Links Available", f"No suitable links are currently available for '{original_event_name.split(' - ')[0]}'.")
    except Exception as e:
        xbmcgui.Dialog().ok(f"{ADDON_NAME} - Error", f"An error occurred while listing links for '{original_event_name.split(' - ')[0]}'.\nCheck log for details.")
        log(f"Error in list_links for {channel_page_url}: {e}", xbmc.LOGERROR)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def find_stream_url_in_html(html_content, page_url_for_logging="Unknown Page"):
    stream_url, method_found = None, "Unknown"
    if not html_content:
        log(f"[{page_url_for_logging}] HTML content is empty, cannot find stream.", xbmc.LOGWARNING)
        return None, method_found

    atob_pattern = r'source\s*:\s*window\.atob\s*\(\s*[\'"]([a-zA-Z0-9+/=]+)[\'"]\s*\)'
    match = re.search(atob_pattern, html_content, re.IGNORECASE)
    if match:
        encoded_url = match.group(1)
        log(f"[{page_url_for_logging}] Found Base64 encoded segment (atob): ...{encoded_url[-30:]}", xbmc.LOGDEBUG)
        try:
            decoded_str = base64.b64decode(encoded_url).decode('utf-8')
            if decoded_str.startswith('http') and ('.m3u8' in decoded_str or '.mpd' in decoded_str):
                stream_url = decoded_str
                method_found = "atob_decode"
                log(f"[{page_url_for_logging}] Decoded stream URL via {method_found}: {stream_url}", xbmc.LOGDEBUG)
                return stream_url, method_found
            else:
                log(f"[{page_url_for_logging}] Decoded string via atob not a valid stream URL: '{decoded_str[:100]}...'", xbmc.LOGWARNING)
        except Exception as e:
            log(f"[{page_url_for_logging}] Base64 decoding (atob) failed: {e}", xbmc.LOGERROR)
    
    if not stream_url:
        patterns = [
            r'\b(?:source|src|file|hlsSource|manifestUrl|video_url)\s*[:=]\s*["\'](https?://[^"\']+\.(?:m3u8|mpd)[^"\']*)["\']',
            r'playerInstance\.load\s*\(\s*\{\s*file\s*:\s*["\'](https?://[^"\']+\.(?:m3u8|mpd)[^"\']*)["\']', 
            r'new\s+Clappr\.Player\s*\(\s*\{\s*source\s*:\s*["\'](https?://[^"\']+\.(?:m3u8|mpd)[^"\']*)["\']', 
            r'player\.src\s*\(\s*["\'](https?://[^"\']+\.(?:m3u8|mpd)[^"\']*)["\']', 
            r'video\.src\s*=\s*["\'](https?://[^"\']+\.(?:m3u8|mpd)[^"\']*)["\']',
            r'stream\.src\s*=\s*["\'](https?://[^"\']+\.(?:m3u8|mpd)[^"\']*)["\']',
            r'["\'](https?://[^"\']+\.(?:m3u8|mpd)[^"\']*)["\']' 
        ]
        for i, pattern in enumerate(patterns):
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                stream_url = match.group(1).replace('\\/', '/')
                method_found = f"direct_regex_pattern_idx_{i}"
                log(f"[{page_url_for_logging}] Found stream URL via {method_found}: {stream_url}", xbmc.LOGDEBUG)
                return stream_url, method_found

    if not stream_url:
        log(f"[{page_url_for_logging}] Direct/atob patterns failed, checking for JSON data...", xbmc.LOGDEBUG)
        json_candidates = []
        try:
            json_block_matches = re.findall(r'(?:data-page=|player\.setup\(|videoPlayer\(|new\s+\w+\.Player\(|(?:var|let|const)\s+[\w\.]+\s*=\s*)\s*([\'"]?)({.*?})\1\s*(?:[;,]|\)\s*;)', html_content, re.DOTALL | re.IGNORECASE)
            for quote_char, json_block in json_block_matches:
                json_candidates.append(json_block)
            
            soup_json = BeautifulSoup(html_content, 'html.parser')
            script_tags_json = soup_json.find_all('script', type=lambda x: x and 'json' in x.lower())
            for script_tag in script_tags_json:
                if script_tag.string:
                    json_candidates.append(script_tag.string.strip())

            found_in_json = False
            for i, json_str_candidate in enumerate(json_candidates):
                try:
                    json_str_candidate = re.sub(r';\s*$', '', json_str_candidate)
                    json_str_candidate = re.sub(r',\s*([}\]])', r'\1', json_str_candidate)
                    data = json.loads(json_str_candidate)
                    paths_to_check = [
                        ['source'], ['sources', 0, 'file'], ['sources', 0, 'src'], ['sources', 0, 'url'],
                        ['props', 'pageProps', 'video', 'url'], 
                        ['props', 'streamData', 'streamurl'],
                        ['config', 'playlist', 0, 'file'], ['config', 'playlist', 0, 'sources', 0, 'file'],
                        ['source', 'file'], ['streamurl'], ['streamUrl'], ['file'], ['hls'], ['url'], ['src'],
                        ['player', 'source'], ['video', 'source'], ['media', 'source'],
                        ['config', 'source'], ['config', 'file'], ['data', 'stream', 'url'],
                    ]
                    def get_nested_value(data_dict, path_list):
                        current_val = data_dict
                        try:
                            for key_or_index in path_list:
                                if isinstance(current_val, list) and isinstance(key_or_index, int) and key_or_index < len(current_val):
                                    current_val = current_val[key_or_index]
                                elif isinstance(current_val, dict):
                                    current_val = current_val.get(key_or_index)
                                    if current_val is None: return None
                                else: return None
                            return current_val
                        except (TypeError, IndexError, KeyError): return None

                    for path in paths_to_check:
                        s_url = get_nested_value(data, path)
                        if isinstance(s_url, str) and ('.m3u8' in s_url or '.mpd' in s_url):
                            stream_url = s_url.replace('\\/','/')
                            method_found = f"json_data (candidate {i}, path: {path})"
                            log(f"[{page_url_for_logging}] Found stream URL in JSON data via {method_found}: {stream_url}", xbmc.LOGDEBUG)
                            found_in_json = True; break
                    if found_in_json: break
                except json.JSONDecodeError: pass 
                except Exception as e_json_proc:
                    log(f"[{page_url_for_logging}] Unexpected error processing JSON candidate {i}: {e_json_proc}", xbmc.LOGDEBUG)
                    pass
            if not found_in_json and json_candidates: log(f"[{page_url_for_logging}] Checked {len(json_candidates)} JSON candidates, no valid stream URL found.", xbmc.LOGDEBUG)
            elif not json_candidates: log(f"[{page_url_for_logging}] No JSON candidates found by regex/script tag search.", xbmc.LOGDEBUG)
        except Exception as e_json_general:
            log(f"[{page_url_for_logging}] Error during general JSON processing: {e_json_general}", xbmc.LOGERROR)

    if not stream_url:
        log(f"[{page_url_for_logging}] No stream URL found using any pattern.", xbmc.LOGWARNING)
    return stream_url, method_found

def resolve_link(player_url, event_name, referer_for_player_fetch):
    log(f"Resolving link for: '{event_name}' -> Player URL: {player_url} (Referer for player fetch: {referer_for_player_fetch})")
    stream_url, final_kodi_url, method_found = None, None, "Unknown"
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
    
    xbmcgui.Dialog().notification(ADDON_NAME, f"Loading: {event_name.split(' - ')[0]}...", xbmcgui.NOTIFICATION_INFO, 3000, sound=False)
    html_content_l3 = get_html_content(player_url, referer_url=referer_for_player_fetch)
    if not html_content_l3:
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem(event_name))
        return

    referer_for_stream_headers = player_url 
    
    try:
        log(f"Attempting to find stream URL in L3 content of {player_url}...")
        stream_url, method_found = find_stream_url_in_html(html_content_l3, page_url_for_logging=player_url)

        if not stream_url and ('foothubhd.online/cdn3/' in player_url or 'vodkapr3mium.com/embed.js' in html_content_l3):
            log(f"L3 stream not found. Checking for vodkapr3mium JS embed pattern on {player_url}...", xbmc.LOGDEBUG)
            fid_match = re.search(r'<script>fid\s*=\s*["\']([^"\']+)["\'];.*?<script.*?src\s*=\s*["\'](?://vodkapr3mium\.com/embed\.js)["\']', html_content_l3, re.DOTALL | re.IGNORECASE)
            if fid_match:
                fid_value = fid_match.group(1)
                log(f"Found vodkapr3mium embed.js pattern with fid: {fid_value}", xbmc.LOGDEBUG)
                l4_vodkapremium_url = f"https://vodkapr3mium.com/embed.php?player=desktop&live={fid_value}"
                log(f"Constructed L4 URL for vodkapr3mium: {l4_vodkapremium_url}", xbmc.LOGDEBUG)
                
                xbmcgui.Dialog().notification(ADDON_NAME, "Processing source...", xbmcgui.NOTIFICATION_INFO, 2000, sound=False)
                html_content_l4 = get_html_content(l4_vodkapremium_url, referer_url=player_url)
                if html_content_l4:
                    log(f"Attempting to find stream URL in L4 content of {l4_vodkapremium_url}...", xbmc.LOGDEBUG)
                    stream_url, method_found = find_stream_url_in_html(html_content_l4, page_url_for_logging=l4_vodkapremium_url)
                    if stream_url:
                        referer_for_stream_headers = l4_vodkapremium_url
                        log(f"Stream found in L4 vodkapr3mium content ({l4_vodkapremium_url}) via {method_found}.", xbmc.LOGDEBUG)
                    else:
                        log(f"Stream URL not found in L4 vodkapr3mium content: {l4_vodkapremium_url}", xbmc.LOGWARNING)
                else:
                    log(f"Failed to fetch L4 vodkapr3mium content from {l4_vodkapremium_url}.", xbmc.LOGWARNING)
            else:
                log(f"vodkapr3mium embed.js pattern (fid extraction) not found on {player_url}.", xbmc.LOGDEBUG)
        
        if not stream_url:
            log(f"Stream not found directly or via known JS embeds in L3 ({player_url}), checking for generic nested iframes...", xbmc.LOGDEBUG)
            soup_l3 = BeautifulSoup(html_content_l3, 'html.parser')
            nested_iframe_tags = soup_l3.find_all('iframe', src=True) 
            if not nested_iframe_tags:
                nested_iframe_tags = soup_l3.find_all('iframe')

            if nested_iframe_tags:
                log(f"Found {len(nested_iframe_tags)} nested iframe(s) in {player_url}. Checking...", xbmc.LOGDEBUG)
                for i, nested_iframe_tag in enumerate(nested_iframe_tags):
                     nested_iframe_src = nested_iframe_tag.get('src')
                     if not nested_iframe_src:
                         log(f"Nested iframe {i+1} has no 'src' attribute. Skipping.", xbmc.LOGDEBUG)
                         continue
                     
                     nested_iframe_url = nested_iframe_src.strip()
                     if not nested_iframe_url or nested_iframe_url.lower() in ['about:blank', 'javascript:false']:
                         log(f"Nested iframe {i+1} 'src' is empty or invalid ('{nested_iframe_url}'). Skipping.", xbmc.LOGDEBUG)
                         continue

                     if nested_iframe_url.startswith('//'): nested_iframe_url = 'https:' + nested_iframe_url
                     elif not nested_iframe_url.startswith('http'): nested_iframe_url = urljoin(player_url, nested_iframe_url)
                     
                     log(f"Checking nested iframe ({i+1}) source: {nested_iframe_url}", xbmc.LOGDEBUG)
                     xbmcgui.Dialog().notification(ADDON_NAME, "Processing source...", xbmcgui.NOTIFICATION_INFO, 2000, sound=False)
                     
                     html_content_l4 = get_html_content(nested_iframe_url, referer_url=player_url)
                     if html_content_l4:
                         log(f"Attempting to find stream URL in L4 content of {nested_iframe_url}...", xbmc.LOGDEBUG)
                         stream_url, method_found = find_stream_url_in_html(html_content_l4, page_url_for_logging=nested_iframe_url)
                         if stream_url:
                             referer_for_stream_headers = nested_iframe_url 
                             log(f"Stream found in L4 content ({nested_iframe_url}) via {method_found}. Referer for stream headers set to: {referer_for_stream_headers}", xbmc.LOGDEBUG)
                             break 
                         else: log(f"Stream URL not found in this L4 iframe: {nested_iframe_url}", xbmc.LOGDEBUG)
                     else: log(f"Failed to fetch nested iframe L4 content from {nested_iframe_url}.", xbmc.LOGWARNING)
                if not stream_url and nested_iframe_tags: log(f"Checked all {len(nested_iframe_tags)} nested iframes in {player_url}, no stream URL found.", xbmc.LOGWARNING)
            else: log(f"No generic nested iframe tags found in L3 content of {player_url}.", xbmc.LOGDEBUG)

        if stream_url:
            if not stream_url.startswith('http'):
                log(f"Stream URL '{stream_url}' is relative. Attempting to make it absolute using the page it was found on: {referer_for_stream_headers}", xbmc.LOGDEBUG)
                stream_url = urljoin(referer_for_stream_headers, stream_url)
                log(f"Absolutized stream URL: {stream_url}", xbmc.LOGDEBUG)

            headers_for_kodi_list = [f'User-Agent={user_agent}']
            if referer_for_stream_headers:
                headers_for_kodi_list.append(f'Referer={referer_for_stream_headers}')
            
            needs_origin = False
            origin_trigger_domains_player_page = ['gt3rs.net', 'weblivehdplay.ru', 'liveon.sx', 'castcc.net', 'cdnhdplay.xyz', 
                                                'foothubhd.online', 'volis.plirolimenas.xyz', 'palis.nomimenos.xyz', 'bcast.ws', 
                                                'sportsbay.org', 'streamservicehd.com', 'vodkapr3mium.com', 'ezcaster.click', 
                                                'quest4play.xyz', 'catchthrust.net', 'hugerelease.net', 'tipotv.com', 'duko.eachna.fun']
            
            try:
                player_page_netloc = urlparse(referer_for_stream_headers).netloc
                if any(domain in player_page_netloc for domain in origin_trigger_domains_player_page):
                    needs_origin = True
                    log(f"Player page domain '{player_page_netloc}' suggests Origin header might be needed.", xbmc.LOGDEBUG)
            except Exception as parse_err:
                log(f"Could not parse referer '{referer_for_stream_headers}' for Origin domain check: {parse_err}", xbmc.LOGWARNING)

            if needs_origin:
                try:
                    parsed_origin_uri = urlparse(referer_for_stream_headers)
                    origin_val = f"{parsed_origin_uri.scheme}://{parsed_origin_uri.netloc}"
                    headers_for_kodi_list.append(f"Origin={origin_val}")
                    log(f"Added Origin header: {origin_val}", xbmc.LOGDEBUG)
                except Exception as parse_e:
                    log(f"Error parsing '{referer_for_stream_headers}' for Origin header construction: {parse_e}", xbmc.LOGWARNING)
            
            final_kodi_url = f'{stream_url}|{"&".join(headers_for_kodi_list)}'
            log(f"Constructed final Kodi URL: {final_kodi_url}", xbmc.LOGINFO)

    except Exception as e:
        xbmcgui.Dialog().ok(f"{ADDON_NAME} - Playback Error", f"An error occurred while trying to play '{event_name.split(' - ')[0]}'.\nPlease try another link or check the log for details.")
        log(f"Error in resolve_link processing for {player_url}: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem(event_name)); return

    if final_kodi_url and stream_url:
        log(f"Attempting to play: {stream_url} (Method: {method_found})")
        
        li = xbmcgui.ListItem(event_name) 
        li.setPath(final_kodi_url)

        art_data = {'icon': DEFAULT_ICON, 'thumb': DEFAULT_ICON}
        if os.path.exists(ADDON_FANART): art_data['fanart'] = ADDON_FANART
        li.setArt(art_data)
        
        infotag = li.getVideoInfoTag()
        infotag.setTitle(event_name)
        infotag.setPlot(f"Playing: {event_name.split(' - ')[0]}") # Generic plot for user
        infotag.setMediaType('video')
        
        li.setProperty('IsPlayable', 'true')
        
        stream_type_is_set = False
        if '.mpd' in stream_url.lower():
            li.setMimeType('application/dash+xml')
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            stream_type_is_set = True
        elif '.m3u8' in stream_url.lower():
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            stream_type_is_set = True
        
        if stream_type_is_set: log(f"Using inputstream.adaptive for {method_found} playback.", xbmc.LOGDEBUG)
        else: log(f"Unknown stream extension for {stream_url}. Attempting direct playback.", xbmc.LOGDEBUG)

        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=True, listitem=li)
    else:
        xbmcgui.Dialog().ok(f"{ADDON_NAME} - Resolution Failed", f"Could not find a playable stream for '{event_name.split(' - ')[0]}'.\nPlease try another link or check the log for details.")
        log(f"Failed to resolve stream URL for '{event_name}'. Player URL: {player_url}, Method Attempted: {method_found}, Final Stream URL (if any): {stream_url}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem(event_name))

# --- Main Execution Logic ---
if __name__ == '__main__':
    log(f"Addon started. Mode: '{mode}', URL: '{url}', Name: '{name}', Referer Param: '{referer}'")
    if mode is None:
        list_channels()
    elif mode == 'list_links':
        if url and name:
            list_links(channel_page_url=url, original_event_name=name)
        else:
            log("List_links mode called with missing URL or Name", xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)
    elif mode == 'resolve_link':
        if url and name and referer: 
            resolve_link(player_url=url, event_name=name, referer_for_player_fetch=referer)
        else:
            log(f"Resolve_link mode called with missing params: URL='{url}', Name='{name}', Referer='{referer}'", xbmc.LOGERROR)
            xbmcgui.Dialog().ok(f"{ADDON_NAME} - Internal Error", "Could not process the selected link due to missing information. (Details in log)")
            fail_li = xbmcgui.ListItem(name if name else "Error")
            xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=fail_li)
    elif mode == 'noop':
         log("No operation mode called (e.g., disclaimer click). Doing nothing.")
         xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True) 
    else:
        log(f"Unknown mode called: '{mode}'", xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)